// src/contexts/FirebaseContext.js or src/FirebaseContext.js
import { createContext } from 'react';

const FirebaseContext = createContext(null);

export default FirebaseContext;
