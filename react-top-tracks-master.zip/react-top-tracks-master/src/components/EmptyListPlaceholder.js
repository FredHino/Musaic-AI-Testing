import React from "react";

const EmptyListPlaceholder = () => {
  return (
    <div>
      <p>Loading your tracks now!</p>
    </div>
  );
};

export default EmptyListPlaceholder;
