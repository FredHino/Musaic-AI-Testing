import styles from '@/styles/Home.module.css'

const MenuaItems = (props) => {
    
    return(
        <img className={styles.spotifylogoo} src={props.source} />
    );
}
export default MenuaItems;
